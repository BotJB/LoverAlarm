import React from 'react'

function Dashboard() {
  return (
    <div>This is the Dashboard page</div>
  )
}

export default Dashboard