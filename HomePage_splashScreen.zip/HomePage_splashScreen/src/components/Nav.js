import React from 'react'
import logo from '../Images/Logo-NoBG.png'



function Nav({isLoggedIn}) {
  return (
    <nav>
       <div className="logo-container">
        <img src={logo} className="logo" alt="Logo of the website" />
       </div>
       <div>
        
       </div>
       {!isLoggedIn && <button className='nav-btn'>Login</button> }
    </nav>
  )
}

export default Nav