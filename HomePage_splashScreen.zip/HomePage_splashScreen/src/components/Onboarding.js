import React from 'react'

function Onboarding() {
  return (
    <div>Onboarding</div>
  )
}

export default Onboarding